BootStrapped Login credentials:
1) username: admin
   password: admin

2) username: user
   password: user
   
 context-path : /StudentManagement
 h2/console : /StudentManagement/h2-console

 Authorization:
   ADMIN: Has the privilege of performing all the operations.
   USER:  User can only view/save the details.

Demo: https://drive.google.com/drive/folders/1Xt96RjDua3Z5SHUH128unlcIwD8fsfH0?usp=share_link
